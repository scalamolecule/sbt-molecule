/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import molecule.schema.SchemaTransaction
import datomic.{Util, Peer}

object YourDomainSchema extends SchemaTransaction {

  lazy val partitions = Util.list(

    Util.map(":db/ident"             , ":users",
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_partition", ":db.part/db"),

    Util.map(":db/ident"             , ":org",
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_partition", ":db.part/db"),

    Util.map(":db/ident"             , ":business",
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_partition", ":db.part/db")
  )


  lazy val namespaces = Util.list(

    // users_Person -----------------------------------------------------

    Util.map(":db/ident"             , ":users_Person/name",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":users_Person/help",
             ":db/valueType"         , ":db.type/ref",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),


    // org_Person -------------------------------------------------------

    Util.map(":db/ident"             , ":org_Person/name",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":org_Person/help",
             ":db/valueType"         , ":db.type/ref",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),


    // business_Service -------------------------------------------------

    Util.map(":db/ident"             , ":business_Service/answer",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object])
  )
}