/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `business_Service`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait business_Service_0 extends business_Service with Out_0[business_Service_0, business_Service_1, P1, P2] {
  type Next[Attr[_, _], Type] = Attr[business_Service_1[Type], P2[_,_]] with business_Service_1[Type]
  type Stay[Attr[_, _], Type] = Attr[business_Service_0, P1[_]] with business_Service_0
  
  final lazy val answer  : Next[answer , String] = ???
  
  final lazy val answer$ : Next[answer$, Option[String]] = ???
  
  final lazy val answer_ : Stay[answer , String] = ???
  
  final def _Person : users_Person_0 = ???
  final def _Person : org_Person_0 = ???
}
         