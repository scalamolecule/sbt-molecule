/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `business_Service`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait business_Service_2[A, B] extends business_Service with Out_2[business_Service_2, business_Service_3, P3, P4, A, B] {
  type Next[Attr[_, _], Type] = Attr[business_Service_3[A, B, Type], P4[_,_,_,_]] with business_Service_3[A, B, Type]
  type Stay[Attr[_, _], Type] = Attr[business_Service_2[A, B], P3[_,_,_]] with business_Service_2[A, B]
  
  final lazy val answer  : Next[answer , String] = ???
  
  final lazy val answer$ : Next[answer$, Option[String]] = ???
  
  final lazy val answer_ : Stay[answer , String] = ???
  
  final def _Person : users_Person_2[A, B] = ???
  final def _Person : org_Person_2[A, B] = ???

  final def Self : business_Service_2[A, B] with SelfJoin = ???
}
         