/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `business_Service`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait business_Service_5[A, B, C, D, E] extends business_Service with Out_5[business_Service_5, P6, P6, P7, A, B, C, D, E] {
  type Stay[Attr[_, _], Type] = Attr[business_Service_5[A, B, C, D, E], P7[_,_,_,_,_,_,_]] with business_Service_5[A, B, C, D, E]
  
  final lazy val answer_ : Stay[answer , String] = ???
  
  final def _Person : users_Person_5[A, B, C, D, E] = ???
  final def _Person : org_Person_5[A, B, C, D, E] = ???
}