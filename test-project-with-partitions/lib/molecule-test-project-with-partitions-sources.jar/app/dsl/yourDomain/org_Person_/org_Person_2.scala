/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `org_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait org_Person_2[A, B] extends org_Person with Out_2[org_Person_2, org_Person_3, P3, P4, A, B] {
  type Next[Attr[_, _], Type] = Attr[org_Person_3[A, B, Type], P4[_,_,_,_]] with org_Person_3[A, B, Type]
  type Stay[Attr[_, _], Type] = Attr[org_Person_2[A, B], P3[_,_,_]] with org_Person_2[A, B]
  
  final lazy val name  : Next[name , String] = ???
  final lazy val help  : Next[help , Long  ] = ???
  
  final lazy val name$ : Next[name$, Option[String]] = ???
  final lazy val help$ : Next[help$, Option[Long]  ] = ???
  
  final lazy val name_ : Stay[name , String] = ???
  final lazy val help_ : Stay[help , Long  ] = ???
  
  final def Help : OneRef [org_Person, business_Service] with business_Service_2[A, B] = ???

  final def Self : org_Person_2[A, B] with SelfJoin = ???
}
         