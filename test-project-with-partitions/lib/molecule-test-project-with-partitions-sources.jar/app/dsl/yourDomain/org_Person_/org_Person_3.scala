/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `org_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait org_Person_3[A, B, C] extends org_Person with Out_3[org_Person_3, org_Person_4, P4, P5, A, B, C] {
  type Next[Attr[_, _], Type] = Attr[org_Person_4[A, B, C, Type], P5[_,_,_,_,_]] with org_Person_4[A, B, C, Type]
  type Stay[Attr[_, _], Type] = Attr[org_Person_3[A, B, C], P4[_,_,_,_]] with org_Person_3[A, B, C]
  
  final lazy val name  : Next[name , String] = ???
  final lazy val help  : Next[help , Long  ] = ???
  
  final lazy val name$ : Next[name$, Option[String]] = ???
  final lazy val help$ : Next[help$, Option[Long]  ] = ???
  
  final lazy val name_ : Stay[name , String] = ???
  final lazy val help_ : Stay[help , Long  ] = ???
  
  final def Help : OneRef [org_Person, business_Service] with business_Service_3[A, B, C] = ???

  final def Self : org_Person_3[A, B, C] with SelfJoin = ???
}
         