/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `org_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait org_Person_5[A, B, C, D, E] extends org_Person with Out_5[org_Person_5, P6, P6, P7, A, B, C, D, E] {
  type Stay[Attr[_, _], Type] = Attr[org_Person_5[A, B, C, D, E], P7[_,_,_,_,_,_,_]] with org_Person_5[A, B, C, D, E]
  
  final lazy val name_ : Stay[name , String] = ???
  final lazy val help_ : Stay[help , Long  ] = ???
  
  final def Help : OneRef [org_Person, business_Service] with business_Service_5[A, B, C, D, E] = ???
}