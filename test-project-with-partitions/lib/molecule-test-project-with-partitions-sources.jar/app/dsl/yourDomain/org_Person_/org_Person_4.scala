/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `org_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait org_Person_4[A, B, C, D] extends org_Person with Out_4[org_Person_4, org_Person_5, P5, P6, A, B, C, D] {
  type Next[Attr[_, _], Type] = Attr[org_Person_5[A, B, C, D, Type], P6[_,_,_,_,_,_]] with org_Person_5[A, B, C, D, Type]
  type Stay[Attr[_, _], Type] = Attr[org_Person_4[A, B, C, D], P5[_,_,_,_,_]] with org_Person_4[A, B, C, D]
  
  final lazy val name  : Next[name , String] = ???
  final lazy val help  : Next[help , Long  ] = ???
  
  final lazy val name$ : Next[name$, Option[String]] = ???
  final lazy val help$ : Next[help$, Option[Long]  ] = ???
  
  final lazy val name_ : Stay[name , String] = ???
  final lazy val help_ : Stay[help , Long  ] = ???
  
  final def Help : OneRef [org_Person, business_Service] with business_Service_4[A, B, C, D] = ???

  final def Self : org_Person_4[A, B, C, D] with SelfJoin = ???
}
         