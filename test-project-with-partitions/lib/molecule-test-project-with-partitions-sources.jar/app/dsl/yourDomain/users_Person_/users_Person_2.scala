/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `users_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait users_Person_2[A, B] extends users_Person with Out_2[users_Person_2, users_Person_3, P3, P4, A, B] {
  type Next[Attr[_, _], Type] = Attr[users_Person_3[A, B, Type], P4[_,_,_,_]] with users_Person_3[A, B, Type]
  type Stay[Attr[_, _], Type] = Attr[users_Person_2[A, B], P3[_,_,_]] with users_Person_2[A, B]
  
  final lazy val name  : Next[name , String] = ???
  final lazy val help  : Next[help , Long  ] = ???
  
  final lazy val name$ : Next[name$, Option[String]] = ???
  final lazy val help$ : Next[help$, Option[Long]  ] = ???
  
  final lazy val name_ : Stay[name , String] = ???
  final lazy val help_ : Stay[help , Long  ] = ???
  
  final def Help : OneRef [users_Person, business_Service] with business_Service_2[A, B] = ???

  final def Self : users_Person_2[A, B] with SelfJoin = ???
}
         