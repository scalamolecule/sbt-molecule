/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `users_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait users_Person_1[A] extends users_Person with Out_1[users_Person_1, users_Person_2, P2, P3, A] {
  type Next[Attr[_, _], Type] = Attr[users_Person_2[A, Type], P3[_,_,_]] with users_Person_2[A, Type]
  type Stay[Attr[_, _], Type] = Attr[users_Person_1[A], P2[_,_]] with users_Person_1[A]
  
  final lazy val name  : Next[name , String] = ???
  final lazy val help  : Next[help , Long  ] = ???
  
  final lazy val name$ : Next[name$, Option[String]] = ???
  final lazy val help$ : Next[help$, Option[Long]  ] = ???
  
  final lazy val name_ : Stay[name , String] = ???
  final lazy val help_ : Stay[help , Long  ] = ???
  
  final def Help : OneRef [users_Person, business_Service] with business_Service_1[A] = ???

  final def Self : users_Person_1[A] with SelfJoin = ???
}
         