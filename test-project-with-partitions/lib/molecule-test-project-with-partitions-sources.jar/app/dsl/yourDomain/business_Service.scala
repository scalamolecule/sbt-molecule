/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `business_Service`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?



object business_Service extends business_Service_0 with FirstNS {
  final override def apply(eid: Long, eids: Long*): business_Service_0 = ???
  final override def apply(eids: Iterable[Long])  : business_Service_0 = ???
}

trait business_Service {
  final class answer [Ns, In] extends OneString[Ns, In] with Indexed

  final class answer$[Ns, In] extends OneString$[Ns] with Indexed
}