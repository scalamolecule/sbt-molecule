/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `users_Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?



object users_Person extends users_Person_0 with FirstNS {
  final override def apply(eid: Long, eids: Long*): users_Person_0 = ???
  final override def apply(eids: Iterable[Long])  : users_Person_0 = ???
}

trait users_Person {
  final class name [Ns, In] extends OneString [Ns, In] with Indexed
  final class help [Ns, In] extends OneRefAttr[Ns, In] with Indexed

  final class name$[Ns, In] extends OneString$ [Ns] with Indexed
  final class help$[Ns, In] extends OneRefAttr$[Ns] with Indexed
}