/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import molecule.dsl.actions._
import molecule.dsl._


object Person extends Person_0 with FirstNS {
  def apply(eid: Long, eids: Long*): Person_0 = ???
  def apply(eids: Seq[Long])       : Person_0 = ???
  def apply(eids: Set[Long])       : Person_0 = ???
}

trait Person {
  class name  [Ns, In] extends OneString[Ns, In] with FulltextSearch[Ns, In] with Indexed
  class age   [Ns, In] extends OneInt   [Ns, In] with Indexed
  class gender[Ns, In] extends OneEnum  [Ns, In] with Indexed { private lazy val male, female = EnumValue }

  class name$  [Ns, In] extends OneString$ with FulltextSearch[Ns, In] with Indexed
  class age$   [Ns, In] extends OneInt$    with Indexed
  class gender$[Ns, In] extends OneEnum$   with Indexed { private lazy val male, female = EnumValue }
}

trait Person_0 extends Person with Out_0[Person_0, Person_1, P1, P2] {
  lazy val name    : name  [Person_1[String], P2[_,_]] with Person_1[String] = new name  [Person_1[String], P2[_,_]] with Person_1[String] { override val _kw = ":person/name" }
  lazy val age     : age   [Person_1[Int   ], P2[_,_]] with Person_1[Int   ] = new age   [Person_1[Int   ], P2[_,_]] with Person_1[Int   ] { override val _kw = ":person/age" }
  lazy val gender  : gender[Person_1[String], P2[_,_]] with Person_1[String] = new gender[Person_1[String], P2[_,_]] with Person_1[String] { override val _kw = ":person/gender" }
  
  lazy val name$   : name$  [Person_1[Option[String]], P2[_,_]] with Person_1[Option[String]] = ???
  lazy val age$    : age$   [Person_1[Option[Int]   ], P2[_,_]] with Person_1[Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_1[Option[String]], P2[_,_]] with Person_1[Option[String]] = ???
  
  lazy val name_   : name  [Person_0, P1[_]] with Person_0 = ???
  lazy val age_    : age   [Person_0, P1[_]] with Person_0 = ???
  lazy val gender_ : gender[Person_0, P1[_]] with Person_0 = ???
}
         
trait Person_1[A] extends Person with Out_1[Person_1, Person_2, P2, P3, A] {
  lazy val name    : name  [Person_2[A, String], P3[_,_,_]] with Person_2[A, String] = ???
  lazy val age     : age   [Person_2[A, Int   ], P3[_,_,_]] with Person_2[A, Int   ] = ???
  lazy val gender  : gender[Person_2[A, String], P3[_,_,_]] with Person_2[A, String] = ???
  
  lazy val name$   : name$  [Person_2[A, Option[String]], P3[_,_,_]] with Person_2[A, Option[String]] = ???
  lazy val age$    : age$   [Person_2[A, Option[Int]   ], P3[_,_,_]] with Person_2[A, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_2[A, Option[String]], P3[_,_,_]] with Person_2[A, Option[String]] = ???
  
  lazy val name_   : name  [Person_1[A], P2[_,_]] with Person_1[A] = ???
  lazy val age_    : age   [Person_1[A], P2[_,_]] with Person_1[A] = ???
  lazy val gender_ : gender[Person_1[A], P2[_,_]] with Person_1[A] = ???

  def Self: Person_1[A] with SelfJoin = ???
}
         
trait Person_2[A, B] extends Person with Out_2[Person_2, Person_3, P3, P4, A, B] {
  lazy val name    : name  [Person_3[A, B, String], P4[_,_,_,_]] with Person_3[A, B, String] = ???
  lazy val age     : age   [Person_3[A, B, Int   ], P4[_,_,_,_]] with Person_3[A, B, Int   ] = ???
  lazy val gender  : gender[Person_3[A, B, String], P4[_,_,_,_]] with Person_3[A, B, String] = ???
  
  lazy val name$   : name$  [Person_3[A, B, Option[String]], P4[_,_,_,_]] with Person_3[A, B, Option[String]] = ???
  lazy val age$    : age$   [Person_3[A, B, Option[Int]   ], P4[_,_,_,_]] with Person_3[A, B, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_3[A, B, Option[String]], P4[_,_,_,_]] with Person_3[A, B, Option[String]] = ???
  
  lazy val name_   : name  [Person_2[A, B], P3[_,_,_]] with Person_2[A, B] = ???
  lazy val age_    : age   [Person_2[A, B], P3[_,_,_]] with Person_2[A, B] = ???
  lazy val gender_ : gender[Person_2[A, B], P3[_,_,_]] with Person_2[A, B] = ???

  def Self: Person_2[A, B] with SelfJoin = ???
}
         
trait Person_3[A, B, C] extends Person with Out_3[Person_3, P4, P4, P5, A, B, C] {
  lazy val name_   : name  [Person_3[A, B, C], P4[_,_,_,_]] with Person_3[A, B, C] = ???
  lazy val age_    : age   [Person_3[A, B, C], P4[_,_,_,_]] with Person_3[A, B, C] = ???
  lazy val gender_ : gender[Person_3[A, B, C], P4[_,_,_,_]] with Person_3[A, B, C] = ???
}