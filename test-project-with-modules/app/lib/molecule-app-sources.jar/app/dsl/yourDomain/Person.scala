/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.in1._
import molecule.boilerplate.in2._
import molecule.boilerplate.in3._
import molecule.boilerplate.out._
import molecule.api._


/** == Namespace `Person` == */
object Person extends Person_0 with FirstNS {
  override def apply(eid: Long, eids: Long*): Person_0 = ???
  override def apply(eids: Iterable[Long])  : Person_0 = ???
}

trait Person {

  // name -----------------------------------------------------------------------------------

  /** Adds mandatory cardinality-one attribute '''`name`''' of type `String` to the molecule.
    * <br><br>
    * Semantics of '''`name`''' being mandatory:
    * <br>- If molecule is queried, only entities having a value for '''`name`''' will be returned.
    * <br>- If insert, save or update is executed on the molecule, the mandatory '''`name`''' attribute
    * needs value(s) applied.
    */
  def name: AnyRef = ???


  /** Adds optional cardinality-one attribute '''`name`''' of type `String` to the molecule.
    * <br><br>
    * Semantics of '''`name`''' being optional:
    * <br>- If molecule is queried, '''`name`''' values asserted with entities matching the molecule are returned as
    * Some(value), otherwise None. Similar to allowing null values.
    * <br>- If insert, save or update is executed on the molecule, Some(value(s)) or None can
    * be applied to '''`name`'''.
    */
  def name$: AnyRef = ???


  /** Adds tacit cardinality-one attribute '''`name`''' of type `String` to the molecule.
    * <br><br>
    * Semantics of '''`name`''' being tacit:
    * <br>- If molecule is queried, only entities having '''`name`''' values asserted will match,
    * but '''`name`''' values are not returned in the result set (are 'tacit').
    */
  def name_ : AnyRef = ???
  
  
  // age -----------------------------------------------------------------------------------

  /** Adds mandatory cardinality-one attribute '''`age`''' of type `Int` to the molecule.
    * <br><br>
    * Semantics of '''`age`''' being mandatory:
    * <br>- If molecule is queried, only entities having a value for '''`age`''' will be returned.
    * <br>- If insert, save or update is executed on the molecule, the mandatory '''`age`''' attribute
    * needs value(s) applied.
    */
  def age: AnyRef = ???


  /** Adds optional cardinality-one attribute '''`age`''' of type `Int` to the molecule.
    * <br><br>
    * Semantics of '''`age`''' being optional:
    * <br>- If molecule is queried, '''`age`''' values asserted with entities matching the molecule are returned as
    * Some(value), otherwise None. Similar to allowing null values.
    * <br>- If insert, save or update is executed on the molecule, Some(value(s)) or None can
    * be applied to '''`age`'''.
    */
  def age$: AnyRef = ???


  /** Adds tacit cardinality-one attribute '''`age`''' of type `Int` to the molecule.
    * <br><br>
    * Semantics of '''`age`''' being tacit:
    * <br>- If molecule is queried, only entities having '''`age`''' values asserted will match,
    * but '''`age`''' values are not returned in the result set (are 'tacit').
    */
  def age_ : AnyRef = ???
  
  
  // gender -----------------------------------------------------------------------------------

  trait gender__enums__{ private lazy val male, female = EnumValue }

  /** Adds mandatory cardinality-one enum attribute '''`gender`''' of type String to the molecule.
    * <br><br>
    * Enums available:
    * <br> - male
    * <br> - female
    * <br><br>
    * Semantics of '''`gender`''' being mandatory:
    * <br>- If molecule is queried, only entities having a value for '''`gender`''' will be returned.
    * <br>- If insert, save or update is executed on the molecule, the mandatory '''`gender`''' attribute
    * needs value(s) applied.
    */
  def gender: AnyRef = ???


  /** Adds optional cardinality-one enum attribute '''`gender`''' of type String to the molecule.
    * <br><br>
    * Enums available:
    * <br> - male
    * <br> - female
    * <br><br>
    * Semantics of '''`gender`''' being optional:
    * <br>- If molecule is queried, '''`gender`''' values asserted with entities matching the molecule are returned as
    * Some(value), otherwise None. Similar to allowing null values.
    * <br>- If insert, save or update is executed on the molecule, Some(value(s)) or None can
    * be applied to '''`gender`'''.
    */
  def gender$: AnyRef = ???


  /** Adds tacit cardinality-one enum attribute '''`gender`''' of type String to the molecule.
    * <br><br>
    * Enums available:
    * <br> - male
    * <br> - female
    * <br><br>
    * Semantics of '''`gender`''' being tacit:
    * <br>- If molecule is queried, only entities having '''`gender`''' values asserted will match,
    * but '''`gender`''' values are not returned in the result set (are 'tacit').
    */
  def gender_ : AnyRef = ???
  
  
  // SELF JOIN -----------------------------------------------------------------------------------

  /** Adds Self join to the molecule.
    * <br><br>
    * Attributes before '''`Self`''' are joined with attributes added after '''`Self`''' by values that can unify:
    * <br><br>
    * Example of
    * {{{
    *   Person.name.age(23).Drinks.beverage._Person.Self // create self join
    *         .name.age(25).Drinks.beverage_(unify)      // unify by beverage
    *         .get === List(
    *           ("Joe", 23, "Coffee", "Ben", 25),  // Joe (23) and Ben(25) both like coffee
    *           ("Liz", 23, "Coffee", "Ben", 25),  // Liz (23) and Ben(25) both like coffee
    *           ("Liz", 23, "Tea", "Ben", 25)      // Liz (23) and Ben(25) both like tea
    *         )
    * }}}
    */
  protected trait Self extends SelfJoin
}

trait Person_0 extends Person with Out_0[Person_0, Person_1, P1, P2] {
  override def name    : Person_1[String] with OneString[Person_1[String], P2[_,_]] with Indexed with FulltextSearch[Person_1[String], P2[_,_]] = ???
  override def age     : Person_1[Int   ] with OneInt   [Person_1[Int   ], P2[_,_]] with Indexed = ???
  override def gender  : Person_1[String] with OneEnum  [Person_1[String], P2[_,_]] with Indexed with gender__enums__ = ???
  
  override def name$   : Person_1[Option[String]] with OneString$[Person_1[Option[String]]] with Indexed with FulltextSearch[Person_1[Option[String]], P2[_,_]] = ???
  override def age$    : Person_1[Option[Int]   ] with OneInt$   [Person_1[Option[Int]   ]] with Indexed = ???
  override def gender$ : Person_1[Option[String]] with OneEnum$  [Person_1[Option[String]]] with Indexed with gender__enums__ = ???
  
  override def name_   : Person_0 with OneString[Person_0, P1[_]] with Indexed with FulltextSearch[Person_0, P1[_]] = ???
  override def age_    : Person_0 with OneInt   [Person_0, P1[_]] with Indexed = ???
  override def gender_ : Person_0 with OneEnum  [Person_0, P1[_]] with Indexed with gender__enums__ = ???
}
         
trait Person_1[A] extends Person with Out_1[Person_1, Person_2, P2, P3, A] {
  override def name    : Person_2[A, String] with OneString[Person_2[A, String], P3[_,_,_]] with Indexed with FulltextSearch[Person_2[A, String], P3[_,_,_]] = ???
  override def age     : Person_2[A, Int   ] with OneInt   [Person_2[A, Int   ], P3[_,_,_]] with Indexed = ???
  override def gender  : Person_2[A, String] with OneEnum  [Person_2[A, String], P3[_,_,_]] with Indexed with gender__enums__ = ???
  
  override def name$   : Person_2[A, Option[String]] with OneString$[Person_2[A, Option[String]]] with Indexed with FulltextSearch[Person_2[A, Option[String]], P3[_,_,_]] = ???
  override def age$    : Person_2[A, Option[Int]   ] with OneInt$   [Person_2[A, Option[Int]   ]] with Indexed = ???
  override def gender$ : Person_2[A, Option[String]] with OneEnum$  [Person_2[A, Option[String]]] with Indexed with gender__enums__ = ???
  
  override def name_   : Person_1[A] with OneString[Person_1[A], P2[_,_]] with Indexed with FulltextSearch[Person_1[A], P2[_,_]] = ???
  override def age_    : Person_1[A] with OneInt   [Person_1[A], P2[_,_]] with Indexed = ???
  override def gender_ : Person_1[A] with OneEnum  [Person_1[A], P2[_,_]] with Indexed with gender__enums__ = ???

  object Self extends Self with Person_1[A]
}
         
trait Person_2[A, B] extends Person with Out_2[Person_2, Person_3, P3, P4, A, B] {
  override def name    : Person_3[A, B, String] with OneString[Person_3[A, B, String], P4[_,_,_,_]] with Indexed with FulltextSearch[Person_3[A, B, String], P4[_,_,_,_]] = ???
  override def age     : Person_3[A, B, Int   ] with OneInt   [Person_3[A, B, Int   ], P4[_,_,_,_]] with Indexed = ???
  override def gender  : Person_3[A, B, String] with OneEnum  [Person_3[A, B, String], P4[_,_,_,_]] with Indexed with gender__enums__ = ???
  
  override def name$   : Person_3[A, B, Option[String]] with OneString$[Person_3[A, B, Option[String]]] with Indexed with FulltextSearch[Person_3[A, B, Option[String]], P4[_,_,_,_]] = ???
  override def age$    : Person_3[A, B, Option[Int]   ] with OneInt$   [Person_3[A, B, Option[Int]   ]] with Indexed = ???
  override def gender$ : Person_3[A, B, Option[String]] with OneEnum$  [Person_3[A, B, Option[String]]] with Indexed with gender__enums__ = ???
  
  override def name_   : Person_2[A, B] with OneString[Person_2[A, B], P3[_,_,_]] with Indexed with FulltextSearch[Person_2[A, B], P3[_,_,_]] = ???
  override def age_    : Person_2[A, B] with OneInt   [Person_2[A, B], P3[_,_,_]] with Indexed = ???
  override def gender_ : Person_2[A, B] with OneEnum  [Person_2[A, B], P3[_,_,_]] with Indexed with gender__enums__ = ???

  object Self extends Self with Person_2[A, B]
}
         
trait Person_3[A, B, C] extends Person with Out_3[Person_3, P4, P4, P5, A, B, C] {
  override def name_   : Person_3[A, B, C] with OneString[Person_3[A, B, C], P4[_,_,_,_]] with Indexed with FulltextSearch[Person_3[A, B, C], P4[_,_,_,_]] = ???
  override def age_    : Person_3[A, B, C] with OneInt   [Person_3[A, B, C], P4[_,_,_,_]] with Indexed = ???
  override def gender_ : Person_3[A, B, C] with OneEnum  [Person_3[A, B, C], P4[_,_,_,_]] with Indexed with gender__enums__ = ???
}