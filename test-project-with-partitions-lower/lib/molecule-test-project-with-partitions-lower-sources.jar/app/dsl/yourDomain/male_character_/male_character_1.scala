/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `male_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait male_character_1[A] extends male_character with Out_1[male_character_1, male_character_2, P2, P3, A] {
  type Next[Attr[_, _], Type] = Attr[male_character_2[A, Type], P3[_,_,_]] with male_character_2[A, Type]
  type Stay[Attr[_, _], Type] = Attr[male_character_1[A], P2[_,_]] with male_character_1[A]
  
  final lazy val name    : Next[name   , String] = ???
  final lazy val mood    : Next[mood   , String] = ???
  final lazy val answer  : Next[answer , Long  ] = ???
  
  final lazy val name$   : Next[name$  , Option[String]] = ???
  final lazy val mood$   : Next[mood$  , Option[String]] = ???
  final lazy val answer$ : Next[answer$, Option[Long]  ] = ???
  
  final lazy val name_   : Stay[name   , String] = ???
  final lazy val mood_   : Stay[mood   , String] = ???
  final lazy val answer_ : Stay[answer , Long  ] = ???
  
  final def Answer : OneRef [male_character, story_conversation] with story_conversation_1[A] = ???

  final def Self : male_character_1[A] with SelfJoin = ???
}
         