/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `male_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait male_character_5[A, B, C, D, E] extends male_character with Out_5[male_character_5, P6, P6, P7, A, B, C, D, E] {
  type Stay[Attr[_, _], Type] = Attr[male_character_5[A, B, C, D, E], P7[_,_,_,_,_,_,_]] with male_character_5[A, B, C, D, E]
  
  final lazy val name_   : Stay[name   , String] = ???
  final lazy val mood_   : Stay[mood   , String] = ???
  final lazy val answer_ : Stay[answer , Long  ] = ???
  
  final def Answer : OneRef [male_character, story_conversation] with story_conversation_5[A, B, C, D, E] = ???
}