/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `female_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?



object female_character extends female_character_0 with FirstNS {
  final override def apply(eid: Long, eids: Long*): female_character_0 = ???
  final override def apply(eids: Iterable[Long])  : female_character_0 = ???
}

trait female_character {
  final class name     [Ns, In] extends OneString [Ns, In] with Indexed
  final class mood     [Ns, In] extends OneString [Ns, In] with Indexed
  final class question [Ns, In] extends OneRefAttr[Ns, In] with Indexed

  final class name$    [Ns, In] extends OneString$ [Ns] with Indexed
  final class mood$    [Ns, In] extends OneString$ [Ns] with Indexed
  final class question$[Ns, In] extends OneRefAttr$[Ns] with Indexed
}