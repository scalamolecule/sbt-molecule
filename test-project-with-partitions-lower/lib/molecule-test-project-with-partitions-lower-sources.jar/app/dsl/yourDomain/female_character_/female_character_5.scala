/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `female_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait female_character_5[A, B, C, D, E] extends female_character with Out_5[female_character_5, P6, P6, P7, A, B, C, D, E] {
  type Stay[Attr[_, _], Type] = Attr[female_character_5[A, B, C, D, E], P7[_,_,_,_,_,_,_]] with female_character_5[A, B, C, D, E]
  
  final lazy val name_     : Stay[name     , String] = ???
  final lazy val mood_     : Stay[mood     , String] = ???
  final lazy val question_ : Stay[question , Long  ] = ???
  
  final def Question : OneRef [female_character, story_conversation] with story_conversation_5[A, B, C, D, E] = ???
}