/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `female_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait female_character_0 extends female_character with Out_0[female_character_0, female_character_1, P1, P2] {
  type Next[Attr[_, _], Type] = Attr[female_character_1[Type], P2[_,_]] with female_character_1[Type]
  type Stay[Attr[_, _], Type] = Attr[female_character_0, P1[_]] with female_character_0
  
  final lazy val name      : Next[name     , String] = ???
  final lazy val mood      : Next[mood     , String] = ???
  final lazy val question  : Next[question , Long  ] = ???
  
  final lazy val name$     : Next[name$    , Option[String]] = ???
  final lazy val mood$     : Next[mood$    , Option[String]] = ???
  final lazy val question$ : Next[question$, Option[Long]  ] = ???
  
  final lazy val name_     : Stay[name     , String] = ???
  final lazy val mood_     : Stay[mood     , String] = ???
  final lazy val question_ : Stay[question , Long  ] = ???
  
  final def Question : OneRef [female_character, story_conversation] with story_conversation_0 = ???
}
         