/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `female_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait female_character_2[A, B] extends female_character with Out_2[female_character_2, female_character_3, P3, P4, A, B] {
  type Next[Attr[_, _], Type] = Attr[female_character_3[A, B, Type], P4[_,_,_,_]] with female_character_3[A, B, Type]
  type Stay[Attr[_, _], Type] = Attr[female_character_2[A, B], P3[_,_,_]] with female_character_2[A, B]
  
  final lazy val name      : Next[name     , String] = ???
  final lazy val mood      : Next[mood     , String] = ???
  final lazy val question  : Next[question , Long  ] = ???
  
  final lazy val name$     : Next[name$    , Option[String]] = ???
  final lazy val mood$     : Next[mood$    , Option[String]] = ???
  final lazy val question$ : Next[question$, Option[Long]  ] = ???
  
  final lazy val name_     : Stay[name     , String] = ???
  final lazy val mood_     : Stay[mood     , String] = ???
  final lazy val question_ : Stay[question , Long  ] = ???
  
  final def Question : OneRef [female_character, story_conversation] with story_conversation_2[A, B] = ???

  final def Self : female_character_2[A, B] with SelfJoin = ???
}
         