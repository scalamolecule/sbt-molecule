/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?



object story_conversation extends story_conversation_0 with FirstNS {
  final override def apply(eid: Long, eids: Long*): story_conversation_0 = ???
  final override def apply(eids: Iterable[Long])  : story_conversation_0 = ???
}

trait story_conversation {
  final class says [Ns, In] extends OneString[Ns, In] with Indexed

  final class says$[Ns, In] extends OneString$[Ns] with Indexed
}