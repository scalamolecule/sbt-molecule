/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait story_conversation_5[A, B, C, D, E] extends story_conversation with Out_5[story_conversation_5, P6, P6, P7, A, B, C, D, E] {
  type Stay[Attr[_, _], Type] = Attr[story_conversation_5[A, B, C, D, E], P7[_,_,_,_,_,_,_]] with story_conversation_5[A, B, C, D, E]
  
  final lazy val says_ : Stay[says , String] = ???
  
  final def _male_character : male_character_5[A, B, C, D, E] = ???
  final def _female_character : female_character_5[A, B, C, D, E] = ???
}