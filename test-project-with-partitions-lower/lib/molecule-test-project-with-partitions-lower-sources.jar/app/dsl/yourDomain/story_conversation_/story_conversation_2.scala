/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait story_conversation_2[A, B] extends story_conversation with Out_2[story_conversation_2, story_conversation_3, P3, P4, A, B] {
  type Next[Attr[_, _], Type] = Attr[story_conversation_3[A, B, Type], P4[_,_,_,_]] with story_conversation_3[A, B, Type]
  type Stay[Attr[_, _], Type] = Attr[story_conversation_2[A, B], P3[_,_,_]] with story_conversation_2[A, B]
  
  final lazy val says  : Next[says , String] = ???
  
  final lazy val says$ : Next[says$, Option[String]] = ???
  
  final lazy val says_ : Stay[says , String] = ???
  
  final def _male_character : male_character_2[A, B] = ???
  final def _female_character : female_character_2[A, B] = ???

  final def Self : story_conversation_2[A, B] with SelfJoin = ???
}
         