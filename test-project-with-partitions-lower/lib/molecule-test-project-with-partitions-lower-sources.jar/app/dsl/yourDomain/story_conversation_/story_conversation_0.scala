/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait story_conversation_0 extends story_conversation with Out_0[story_conversation_0, story_conversation_1, P1, P2] {
  type Next[Attr[_, _], Type] = Attr[story_conversation_1[Type], P2[_,_]] with story_conversation_1[Type]
  type Stay[Attr[_, _], Type] = Attr[story_conversation_0, P1[_]] with story_conversation_0
  
  final lazy val says  : Next[says , String] = ???
  
  final lazy val says$ : Next[says$, Option[String]] = ???
  
  final lazy val says_ : Stay[says , String] = ???
  
  final def _male_character : male_character_0 = ???
  final def _female_character : female_character_0 = ???
}
         