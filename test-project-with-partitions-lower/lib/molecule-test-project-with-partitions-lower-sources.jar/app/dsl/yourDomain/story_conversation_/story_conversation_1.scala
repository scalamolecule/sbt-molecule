/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait story_conversation_1[A] extends story_conversation with Out_1[story_conversation_1, story_conversation_2, P2, P3, A] {
  type Next[Attr[_, _], Type] = Attr[story_conversation_2[A, Type], P3[_,_,_]] with story_conversation_2[A, Type]
  type Stay[Attr[_, _], Type] = Attr[story_conversation_1[A], P2[_,_]] with story_conversation_1[A]
  
  final lazy val says  : Next[says , String] = ???
  
  final lazy val says$ : Next[says$, Option[String]] = ???
  
  final lazy val says_ : Stay[says , String] = ???
  
  final def _male_character : male_character_1[A] = ???
  final def _female_character : female_character_1[A] = ???

  final def Self : story_conversation_1[A] with SelfJoin = ???
}
         