/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait story_conversation_4[A, B, C, D] extends story_conversation with Out_4[story_conversation_4, story_conversation_5, P5, P6, A, B, C, D] {
  type Next[Attr[_, _], Type] = Attr[story_conversation_5[A, B, C, D, Type], P6[_,_,_,_,_,_]] with story_conversation_5[A, B, C, D, Type]
  type Stay[Attr[_, _], Type] = Attr[story_conversation_4[A, B, C, D], P5[_,_,_,_,_]] with story_conversation_4[A, B, C, D]
  
  final lazy val says  : Next[says , String] = ???
  
  final lazy val says$ : Next[says$, Option[String]] = ???
  
  final lazy val says_ : Stay[says , String] = ???
  
  final def _male_character : male_character_4[A, B, C, D] = ???
  final def _female_character : female_character_4[A, B, C, D] = ???

  final def Self : story_conversation_4[A, B, C, D] with SelfJoin = ???
}
         