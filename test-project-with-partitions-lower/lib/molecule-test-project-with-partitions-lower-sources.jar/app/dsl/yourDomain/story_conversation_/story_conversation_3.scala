/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `story_conversation`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait story_conversation_3[A, B, C] extends story_conversation with Out_3[story_conversation_3, story_conversation_4, P4, P5, A, B, C] {
  type Next[Attr[_, _], Type] = Attr[story_conversation_4[A, B, C, Type], P5[_,_,_,_,_]] with story_conversation_4[A, B, C, Type]
  type Stay[Attr[_, _], Type] = Attr[story_conversation_3[A, B, C], P4[_,_,_,_]] with story_conversation_3[A, B, C]
  
  final lazy val says  : Next[says , String] = ???
  
  final lazy val says$ : Next[says$, Option[String]] = ???
  
  final lazy val says_ : Stay[says , String] = ???
  
  final def _male_character : male_character_3[A, B, C] = ???
  final def _female_character : female_character_3[A, B, C] = ???

  final def Self : story_conversation_3[A, B, C] with SelfJoin = ???
}
         