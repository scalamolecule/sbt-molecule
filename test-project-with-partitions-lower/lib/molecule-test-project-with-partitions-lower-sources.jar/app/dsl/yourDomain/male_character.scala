/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `male_character`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?



object male_character extends male_character_0 with FirstNS {
  final override def apply(eid: Long, eids: Long*): male_character_0 = ???
  final override def apply(eids: Iterable[Long])  : male_character_0 = ???
}

trait male_character {
  final class name   [Ns, In] extends OneString [Ns, In] with Indexed
  final class mood   [Ns, In] extends OneString [Ns, In] with Indexed
  final class answer [Ns, In] extends OneRefAttr[Ns, In] with Indexed

  final class name$  [Ns, In] extends OneString$ [Ns] with Indexed
  final class mood$  [Ns, In] extends OneString$ [Ns] with Indexed
  final class answer$[Ns, In] extends OneRefAttr$[Ns] with Indexed
}