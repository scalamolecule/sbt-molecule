/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import molecule.schema.SchemaTransaction
import datomic.{Util, Peer}

object YourDomainSchema extends SchemaTransaction {

  lazy val partitions = Util.list(

    Util.map(":db/ident"             , ":male",
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_partition", ":db.part/db"),

    Util.map(":db/ident"             , ":female",
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_partition", ":db.part/db"),

    Util.map(":db/ident"             , ":story",
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_partition", ":db.part/db")
  )


  lazy val namespaces = Util.list(

    // male_character ---------------------------------------------------

    Util.map(":db/ident"             , ":male_character/name",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":male_character/mood",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":male_character/answer",
             ":db/valueType"         , ":db.type/ref",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),


    // female_character -------------------------------------------------

    Util.map(":db/ident"             , ":female_character/name",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":female_character/mood",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":female_character/question",
             ":db/valueType"         , ":db.type/ref",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),


    // story_conversation -----------------------------------------------

    Util.map(":db/ident"             , ":story_conversation/says",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object])
  )
}