/*
* AUTO-GENERATED CODE - DON'T CHANGE!
*
* Manual changes to this file will likely break schema creations!
* Instead, change the molecule definition files and recompile your project with `sbt compile`
*/
package app.schema
import molecule.dsl.Transaction
import datomic.{Util, Peer}

object YourDomainSchema extends Transaction {
  
  lazy val partitions = Util.list()

  lazy val namespaces = Util.list(
    
    // Person -----------------------------------------------------------

    Util.map(":db/ident"             , ":person/name",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/fulltext"          , true.asInstanceOf[Object],
             ":db/index"             , true.asInstanceOf[Object],
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_attribute", ":db.part/db"),

    Util.map(":db/ident"             , ":person/age",
             ":db/valueType"         , ":db.type/long",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object],
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_attribute", ":db.part/db"),

    Util.map(":db/ident"             , ":person/gender",
             ":db/valueType"         , ":db.type/ref",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object],
             ":db/id"                , Peer.tempid(":db.part/db"),
             ":db.install/_attribute", ":db.part/db"),

    Util.map(":db/id", Peer.tempid(":db.part/user"), ":db/ident", ":person.gender/male"),
    Util.map(":db/id", Peer.tempid(":db.part/user"), ":db/ident", ":person.gender/female")
  )
}