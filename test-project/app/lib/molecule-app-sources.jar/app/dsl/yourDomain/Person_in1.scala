/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import molecule.dsl.actions._
import molecule.dsl._



/********* Input molecules awaiting 1 input *******************************/

trait Person_In_1_0[I1] extends Person with In_1_0[Person_In_1_0, Person_In_1_1, P2, P3, I1] {
  lazy val name    : name  [Person_In_1_1[I1, String], P3[_,_,_]] with Person_In_1_1[I1, String] = ???
  lazy val age     : age   [Person_In_1_1[I1, Int   ], P3[_,_,_]] with Person_In_1_1[I1, Int   ] = ???
  lazy val gender  : gender[Person_In_1_1[I1, String], P3[_,_,_]] with Person_In_1_1[I1, String] = ???
  
  lazy val name$   : name$  [Person_In_1_1[I1, Option[String]], P3[_,_,_]] with Person_In_1_1[I1, Option[String]] = ???
  lazy val age$    : age$   [Person_In_1_1[I1, Option[Int]   ], P3[_,_,_]] with Person_In_1_1[I1, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_In_1_1[I1, Option[String]], P3[_,_,_]] with Person_In_1_1[I1, Option[String]] = ???
  
  lazy val name_   : name  [Person_In_1_0[I1], P2[_,_]] with Person_In_1_0[I1] = ???
  lazy val age_    : age   [Person_In_1_0[I1], P2[_,_]] with Person_In_1_0[I1] = ???
  lazy val gender_ : gender[Person_In_1_0[I1], P2[_,_]] with Person_In_1_0[I1] = ???
}
         
trait Person_In_1_1[I1, A] extends Person with In_1_1[Person_In_1_1, Person_In_1_2, P3, P4, I1, A] {
  lazy val name    : name  [Person_In_1_2[I1, A, String], P4[_,_,_,_]] with Person_In_1_2[I1, A, String] = ???
  lazy val age     : age   [Person_In_1_2[I1, A, Int   ], P4[_,_,_,_]] with Person_In_1_2[I1, A, Int   ] = ???
  lazy val gender  : gender[Person_In_1_2[I1, A, String], P4[_,_,_,_]] with Person_In_1_2[I1, A, String] = ???
  
  lazy val name$   : name$  [Person_In_1_2[I1, A, Option[String]], P4[_,_,_,_]] with Person_In_1_2[I1, A, Option[String]] = ???
  lazy val age$    : age$   [Person_In_1_2[I1, A, Option[Int]   ], P4[_,_,_,_]] with Person_In_1_2[I1, A, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_In_1_2[I1, A, Option[String]], P4[_,_,_,_]] with Person_In_1_2[I1, A, Option[String]] = ???
  
  lazy val name_   : name  [Person_In_1_1[I1, A], P3[_,_,_]] with Person_In_1_1[I1, A] = ???
  lazy val age_    : age   [Person_In_1_1[I1, A], P3[_,_,_]] with Person_In_1_1[I1, A] = ???
  lazy val gender_ : gender[Person_In_1_1[I1, A], P3[_,_,_]] with Person_In_1_1[I1, A] = ???
}
         
trait Person_In_1_2[I1, A, B] extends Person with In_1_2[Person_In_1_2, Person_In_1_3, P4, P5, I1, A, B] {
  lazy val name    : name  [Person_In_1_3[I1, A, B, String], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, String] = ???
  lazy val age     : age   [Person_In_1_3[I1, A, B, Int   ], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, Int   ] = ???
  lazy val gender  : gender[Person_In_1_3[I1, A, B, String], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, String] = ???
  
  lazy val name$   : name$  [Person_In_1_3[I1, A, B, Option[String]], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, Option[String]] = ???
  lazy val age$    : age$   [Person_In_1_3[I1, A, B, Option[Int]   ], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_In_1_3[I1, A, B, Option[String]], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, Option[String]] = ???
  
  lazy val name_   : name  [Person_In_1_2[I1, A, B], P4[_,_,_,_]] with Person_In_1_2[I1, A, B] = ???
  lazy val age_    : age   [Person_In_1_2[I1, A, B], P4[_,_,_,_]] with Person_In_1_2[I1, A, B] = ???
  lazy val gender_ : gender[Person_In_1_2[I1, A, B], P4[_,_,_,_]] with Person_In_1_2[I1, A, B] = ???
}
         
trait Person_In_1_3[I1, A, B, C] extends Person with In_1_3[Person_In_1_3, P5, P5, P6, I1, A, B, C] {
  lazy val name_   : name  [Person_In_1_3[I1, A, B, C], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, C] = ???
  lazy val age_    : age   [Person_In_1_3[I1, A, B, C], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, C] = ???
  lazy val gender_ : gender[Person_In_1_3[I1, A, B, C], P5[_,_,_,_,_]] with Person_In_1_3[I1, A, B, C] = ???
}