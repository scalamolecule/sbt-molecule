/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import molecule.dsl.actions._
import molecule.dsl._


object Person extends Person_0 with FirstNS {
  def apply(e: Long): Person_0 = ???
}

trait Person {
  class name  [Ns, In] extends OneString[Ns, In] with FulltextSearch[Ns, In]
  class age   [Ns, In] extends OneInt   [Ns, In]
  class gender[Ns, In] extends OneEnum  [Ns, In] { private lazy val male, female = EnumValue }

  class name$  [Ns, In] extends OneString$ with FulltextSearch[Ns, In]
  class age$   [Ns, In] extends OneInt$   
  class gender$[Ns, In] extends OneEnum$   { private lazy val male, female = EnumValue }
}

trait Person_0 extends Person with Out_0[Person_0, Person_1, Person_In_1_0, Person_In_1_1] {
  lazy val name    : name  [Person_1[String], Person_In_1_1[String, String]] with Person_1[String] = new name  [Person_1[String], Person_In_1_1[String, String]] with Person_1[String] { override val _kw = ":person/name" }
  lazy val age     : age   [Person_1[Int   ], Person_In_1_1[Int   , Int   ]] with Person_1[Int   ] = new age   [Person_1[Int   ], Person_In_1_1[Int   , Int   ]] with Person_1[Int   ] { override val _kw = ":person/age" }
  lazy val gender  : gender[Person_1[String], Person_In_1_1[String, String]] with Person_1[String] = new gender[Person_1[String], Person_In_1_1[String, String]] with Person_1[String] { override val _kw = ":person/gender" }
  
  lazy val name$   : name$  [Person_1[Option[String]], Person_In_1_1[Option[String], Option[String]]] with Person_1[Option[String]] = ???
  lazy val age$    : age$   [Person_1[Option[Int]   ], Person_In_1_1[Option[Int]   , Option[Int]   ]] with Person_1[Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_1[Option[String]], Person_In_1_1[Option[String], Option[String]]] with Person_1[Option[String]] = ???
  
  lazy val name_   : name  [Person_0, Person_In_1_0[String]] with Person_0 = ???
  lazy val age_    : age   [Person_0, Person_In_1_0[Int   ]] with Person_0 = ???
  lazy val gender_ : gender[Person_0, Person_In_1_0[String]] with Person_0 = ???
}
         
trait Person_1[A] extends Person with Out_1[Person_1, Person_2, Person_In_1_1, Person_In_1_2, A] {
  lazy val name    : name  [Person_2[A, String], Person_In_1_2[String, A, String]] with Person_2[A, String] = ???
  lazy val age     : age   [Person_2[A, Int   ], Person_In_1_2[Int   , A, Int   ]] with Person_2[A, Int   ] = ???
  lazy val gender  : gender[Person_2[A, String], Person_In_1_2[String, A, String]] with Person_2[A, String] = ???
  
  lazy val name$   : name$  [Person_2[A, Option[String]], Person_In_1_2[Option[String], A, Option[String]]] with Person_2[A, Option[String]] = ???
  lazy val age$    : age$   [Person_2[A, Option[Int]   ], Person_In_1_2[Option[Int]   , A, Option[Int]   ]] with Person_2[A, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_2[A, Option[String]], Person_In_1_2[Option[String], A, Option[String]]] with Person_2[A, Option[String]] = ???
  
  lazy val name_   : name  [Person_1[A], Person_In_1_1[String, A]] with Person_1[A] = ???
  lazy val age_    : age   [Person_1[A], Person_In_1_1[Int   , A]] with Person_1[A] = ???
  lazy val gender_ : gender[Person_1[A], Person_In_1_1[String, A]] with Person_1[A] = ???

  def Self: Person_1[A] with SelfJoin = ???
}
         
trait Person_2[A, B] extends Person with Out_2[Person_2, Person_3, Person_In_1_2, Person_In_1_3, A, B] {
  lazy val name    : name  [Person_3[A, B, String], Person_In_1_3[String, A, B, String]] with Person_3[A, B, String] = ???
  lazy val age     : age   [Person_3[A, B, Int   ], Person_In_1_3[Int   , A, B, Int   ]] with Person_3[A, B, Int   ] = ???
  lazy val gender  : gender[Person_3[A, B, String], Person_In_1_3[String, A, B, String]] with Person_3[A, B, String] = ???
  
  lazy val name$   : name$  [Person_3[A, B, Option[String]], Person_In_1_3[Option[String], A, B, Option[String]]] with Person_3[A, B, Option[String]] = ???
  lazy val age$    : age$   [Person_3[A, B, Option[Int]   ], Person_In_1_3[Option[Int]   , A, B, Option[Int]   ]] with Person_3[A, B, Option[Int]   ] = ???
  lazy val gender$ : gender$[Person_3[A, B, Option[String]], Person_In_1_3[Option[String], A, B, Option[String]]] with Person_3[A, B, Option[String]] = ???
  
  lazy val name_   : name  [Person_2[A, B], Person_In_1_2[String, A, B]] with Person_2[A, B] = ???
  lazy val age_    : age   [Person_2[A, B], Person_In_1_2[Int   , A, B]] with Person_2[A, B] = ???
  lazy val gender_ : gender[Person_2[A, B], Person_In_1_2[String, A, B]] with Person_2[A, B] = ???

  def Self: Person_2[A, B] with SelfJoin = ???
}
         
trait Person_3[A, B, C] extends Person with Out_3[Person_3, P4, Person_In_1_3, P5, A, B, C] {
  lazy val name_   : name  [Person_3[A, B, C], Person_In_1_3[String, A, B, C]] with Person_3[A, B, C] = ???
  lazy val age_    : age   [Person_3[A, B, C], Person_In_1_3[Int   , A, B, C]] with Person_3[A, B, C] = ???
  lazy val gender_ : gender[Person_3[A, B, C], Person_In_1_3[String, A, B, C]] with Person_3[A, B, C] = ???
}