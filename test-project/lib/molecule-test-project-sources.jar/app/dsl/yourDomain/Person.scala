/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `Person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?



object Person extends Person_0 with FirstNS {
  final override def apply(eid: Long, eids: Long*): Person_0 = ???
  final override def apply(eids: Iterable[Long])  : Person_0 = ???
}

trait Person {
  final class name   [Ns, In] extends OneString[Ns, In] with Indexed with Fulltext[Ns, In]
  final class age    [Ns, In] extends OneInt   [Ns, In] with Indexed
  final class gender [Ns, In] extends OneEnum  [Ns, In] with Indexed { private lazy val male, female = EnumValue }

  final class name$  [Ns, In] extends OneString$[Ns] with Indexed with Fulltext[Ns, In]
  final class age$   [Ns, In] extends OneInt$   [Ns] with Indexed
  final class gender$[Ns, In] extends OneEnum$  [Ns] with Indexed { private lazy val male, female = EnumValue }
}