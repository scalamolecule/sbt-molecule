/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `Person`
*
* To change:
* 1. edit data model file in `app.dataModel/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.core.boilerplate.attributes._
import molecule.core.boilerplate.base._
import molecule.core.boilerplate.dummyTypes._
import molecule.core.boilerplate.out._
import molecule.core.expression.AttrExpressions.?


trait Person_1[A] extends Person with Out_1[Person_1, Person_2, P2, P3, A] {
  type Next[Attr[_, _], Type] = Attr[Person_2[A, Type], P3[_,_,_]] with Person_2[A, Type]
  type Stay[Attr[_, _], Type] = Attr[Person_1[A], P2[_,_]] with Person_1[A]
  
  final lazy val name    : Next[name   , String] = ???
  final lazy val age     : Next[age    , Int   ] = ???
  final lazy val gender  : Next[gender , String] = ???
  
  final lazy val name$   : Next[name$  , Option[String]] = ???
  final lazy val age$    : Next[age$   , Option[Int]   ] = ???
  final lazy val gender$ : Next[gender$, Option[String]] = ???
  
  final lazy val name_   : Stay[name   , String] = ???
  final lazy val age_    : Stay[age    , Int   ] = ???
  final lazy val gender_ : Stay[gender , String] = ???

  final def Self : Person_1[A] with SelfJoin = ???
}
         