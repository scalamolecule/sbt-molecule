/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import datomic.{Util, Peer}

object YourDomainSchemaLowerToUpper {

  lazy val namespaces = Util.list(

    // Person -----------------------------------------------------------

    Util.map(":db/id", ":person/name", ":db/ident", ":Person/name"),

    Util.map(":db/id", ":person/age", ":db/ident", ":Person/age"),

    Util.map(":db/id", ":person/gender", ":db/ident", ":Person/gender"),

    Util.map(":db/id", ":person.gender/male", ":db/ident", ":Person.gender/male"),
    Util.map(":db/id", ":person.gender/female", ":db/ident", ":Person.gender/female")
  )
}