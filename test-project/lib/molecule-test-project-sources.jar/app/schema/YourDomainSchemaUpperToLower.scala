/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import datomic.{Util, Peer}

object YourDomainSchemaUpperToLower {

  lazy val namespaces = Util.list(

    // Person -----------------------------------------------------------

    Util.map(":db/id", ":Person/name", ":db/ident", ":person/name"),

    Util.map(":db/id", ":Person/age", ":db/ident", ":person/age"),

    Util.map(":db/id", ":Person/gender", ":db/ident", ":person/gender"),

    Util.map(":db/id", ":Person.gender/male", ":db/ident", ":person.gender/male"),
    Util.map(":db/id", ":Person.gender/female", ":db/ident", ":person.gender/female")
  )
}