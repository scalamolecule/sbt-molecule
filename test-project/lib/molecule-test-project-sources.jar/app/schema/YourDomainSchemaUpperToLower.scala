/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import datomic.Util._

object YourDomainSchemaUpperToLower {

  lazy val namespaces = list(

    // Person -----------------------------------------------------------

    map(read(":db/id"), read(":Person/name")         , read(":db/ident"), read(":person/name")),
    map(read(":db/id"), read(":Person/age")          , read(":db/ident"), read(":person/age")),
    map(read(":db/id"), read(":Person/gender")       , read(":db/ident"), read(":person/gender")),
    map(read(":db/id"), read(":Person.gender/male")  , read(":db/ident"), read(":person.gender/male")),
    map(read(":db/id"), read(":Person.gender/female"), read(":db/ident"), read(":person.gender/female"))
  )
}