/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import datomic.Util._

object YourDomainSchemaLowerToUpper {

  lazy val namespaces = list(

    // person -----------------------------------------------------------

    map(read(":db/id"), read(":person/name")         , read(":db/ident"), read(":person/name")),
    map(read(":db/id"), read(":person/age")          , read(":db/ident"), read(":person/age")),
    map(read(":db/id"), read(":person/gender")       , read(":db/ident"), read(":person/gender")),
    map(read(":db/id"), read(":person.gender/male")  , read(":db/ident"), read(":person.gender/male")),
    map(read(":db/id"), read(":person.gender/female"), read(":db/ident"), read(":person.gender/female"))
  )
}