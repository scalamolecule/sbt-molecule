/*
* AUTO-GENERATED Datomic schema generation boilerplate code
*
* To change:
* 1. edit data model file in `app.dataModel/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import molecule.core.data.SchemaTransaction
import datomic.Util._
import datomic.Peer._

object YourDomainSchema extends SchemaTransaction {

  lazy val partitions = list()


  lazy val namespaces = list(

    // person -----------------------------------------------------------

    map(read(":db/ident")             , read(":person/name"),
        read(":db/valueType")         , read(":db.type/string"),
        read(":db/cardinality")       , read(":db.cardinality/one"),
        read(":db/fulltext")          , true.asInstanceOf[Object],
        read(":db/index")             , true.asInstanceOf[Object]),

    map(read(":db/ident")             , read(":person/age"),
        read(":db/valueType")         , read(":db.type/long"),
        read(":db/cardinality")       , read(":db.cardinality/one"),
        read(":db/index")             , true.asInstanceOf[Object]),

    map(read(":db/ident")             , read(":person/gender"),
        read(":db/valueType")         , read(":db.type/ref"),
        read(":db/cardinality")       , read(":db.cardinality/one"),
        read(":db/index")             , true.asInstanceOf[Object]),

    map(read(":db/id"), tempid(":db.part/user"), read(":db/ident"), read(":person.gender/male")),
    map(read(":db/id"), tempid(":db.part/user"), read(":db/ident"), read(":person.gender/female"))
  )
}