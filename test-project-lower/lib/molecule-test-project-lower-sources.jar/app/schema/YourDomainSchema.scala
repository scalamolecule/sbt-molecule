/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import molecule.schema.SchemaTransaction
import datomic.{Util, Peer}

object YourDomainSchema extends SchemaTransaction {

  lazy val partitions = Util.list()


  lazy val namespaces = Util.list(

    // person -----------------------------------------------------------

    Util.map(":db/ident"             , ":person/name",
             ":db/valueType"         , ":db.type/string",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/fulltext"          , true.asInstanceOf[Object],
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":person/age",
             ":db/valueType"         , ":db.type/long",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/ident"             , ":person/gender",
             ":db/valueType"         , ":db.type/ref",
             ":db/cardinality"       , ":db.cardinality/one",
             ":db/index"             , true.asInstanceOf[Object]),

    Util.map(":db/id", Peer.tempid(":db.part/user"), ":db/ident", ":person.gender/male"),
    Util.map(":db/id", Peer.tempid(":db.part/user"), ":db/ident", ":person.gender/female")
  )
}