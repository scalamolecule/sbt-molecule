/*
* AUTO-GENERATED Molecule DSL schema boilerplate code
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.schema
import datomic.{Util, Peer}

object YourDomainSchemaUpperToLower {

  lazy val namespaces = Util.list(

    // person -----------------------------------------------------------

    Util.map(":db/id", ":person/name", ":db/ident", ":person/name"),

    Util.map(":db/id", ":person/age", ":db/ident", ":person/age"),

    Util.map(":db/id", ":person/gender", ":db/ident", ":person/gender"),

    Util.map(":db/id", ":person.gender/male", ":db/ident", ":person.gender/male"),
    Util.map(":db/id", ":person.gender/female", ":db/ident", ":person.gender/female")
  )
}