/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `person`
*
* To change:
* 1. edit data model file in `app.dataModel/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.core.boilerplate.attributes._
import molecule.core.boilerplate.base._
import molecule.core.boilerplate.dummyTypes._
import molecule.core.boilerplate.out._
import molecule.core.expression.AttrExpressions.?


trait person_0 extends person with Out_0[person_0, person_1, P1, P2] {
  type Next[Attr[_, _], Type] = Attr[person_1[Type], P2[_,_]] with person_1[Type]
  type Stay[Attr[_, _], Type] = Attr[person_0, P1[_]] with person_0
  
  final lazy val name    : Next[name   , String] = ???
  final lazy val age     : Next[age    , Int   ] = ???
  final lazy val gender  : Next[gender , String] = ???
  
  final lazy val name$   : Next[name$  , Option[String]] = ???
  final lazy val age$    : Next[age$   , Option[Int]   ] = ???
  final lazy val gender$ : Next[gender$, Option[String]] = ???
  
  final lazy val name_   : Stay[name   , String] = ???
  final lazy val age_    : Stay[age    , Int   ] = ???
  final lazy val gender_ : Stay[gender , String] = ???
}
         