/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `person`
*
* To change:
* 1. edit schema definition file in `app.schema/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.boilerplate.attributes._
import molecule.boilerplate.base._
import molecule.boilerplate.dummyTypes._
import molecule.boilerplate.out._
import molecule.expression.AttrExpressions.?


trait person_3[A, B, C] extends person with Out_3[person_3, P4, P4, P5, A, B, C] {
  type Stay[Attr[_, _], Type] = Attr[person_3[A, B, C], P5[_,_,_,_,_]] with person_3[A, B, C]
  
  final lazy val name_   : Stay[name   , String] = ???
  final lazy val age_    : Stay[age    , Int   ] = ???
  final lazy val gender_ : Stay[gender , String] = ???
}