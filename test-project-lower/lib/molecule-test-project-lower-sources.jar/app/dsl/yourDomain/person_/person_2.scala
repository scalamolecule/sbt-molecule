/*
* AUTO-GENERATED Molecule DSL boilerplate code for namespace `person`
*
* To change:
* 1. edit data model file in `app.dataModel/`
* 2. `sbt compile` in terminal
* 3. Refresh and re-compile project in IDE
*/
package app.dsl
package yourDomain
import scala.language.higherKinds
import molecule.core.boilerplate.attributes._
import molecule.core.boilerplate.base._
import molecule.core.boilerplate.dummyTypes._
import molecule.core.boilerplate.out._
import molecule.core.expression.AttrExpressions.?


trait person_2[A, B] extends person with Out_2[person_2, person_3, P3, P4, A, B] {
  type Next[Attr[_, _], Type] = Attr[person_3[A, B, Type], P4[_,_,_,_]] with person_3[A, B, Type]
  type Stay[Attr[_, _], Type] = Attr[person_2[A, B], P3[_,_,_]] with person_2[A, B]
  
  final lazy val name    : Next[name   , String] = ???
  final lazy val age     : Next[age    , Int   ] = ???
  final lazy val gender  : Next[gender , String] = ???
  
  final lazy val name$   : Next[name$  , Option[String]] = ???
  final lazy val age$    : Next[age$   , Option[Int]   ] = ???
  final lazy val gender$ : Next[gender$, Option[String]] = ???
  
  final lazy val name_   : Stay[name   , String] = ???
  final lazy val age_    : Stay[age    , Int   ] = ???
  final lazy val gender_ : Stay[gender , String] = ???

  final def Self : person_2[A, B] with SelfJoin = ???
}
         